package com.urbanmonitor.domain.company.method1.algorithm;

import com.urbanmonitor.domain.company.method1.model.Method1OptimizationParams;
import lombok.extern.slf4j.Slf4j;

/**
 * Buyer side cost calculation
 */
@Slf4j
public class BuyerCostCalculator implements CostCalculator {

    @Override
    public double calculate(double q, double p, int n, double k1,
                            double av, double theta, double ts,
                            Method1OptimizationParams params) {

        double tSafe = Math.max(ts + q / p, 1e-10);

        double t1 = (params.getA0() + n * params.getCt()) * params.getDemand() / (n * q);
        double t2 = params.getHb() * (q / 2 + k1 * params.getSigma() * Math.sqrt(tSafe));

        double ex1 = (params.getSigma() / 2) * Math.sqrt(tSafe) *
                (Math.sqrt(1 + k1 * k1) - k1);

        double ex2 = (params.getSigma() / 2) * Math.sqrt(params.getTt()) *
                (Math.sqrt(1 + k1 * k1 * tSafe / params.getTt()) -
                        k1 * Math.sqrt(tSafe / params.getTt()));

        double t3 = params.getDemand() * params.getPi() / (n * q) * ex1;
        double t4 = params.getDemand() * params.getPi() * (n - 1) / (n * q) * ex2;
        double t5 = params.getDemand() * n * 0.0 / (n * q);  // CR_ts = 0 for now

        return t1 + t2 + t3 + t4 + t5;
    }
}