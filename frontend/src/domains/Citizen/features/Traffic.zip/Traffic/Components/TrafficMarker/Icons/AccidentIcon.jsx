import { TRAFFIC_LEVEL_COLORS} from "../../../../../../../shared/Constants/color.js";
import { HeartHandshake } from "lucide-react";
const AccidentIcon = () => {
    return (
        <div className="traffic-icon-accident">
            <HeartHandshake />
        </div>
    );
};

export default AccidentIcon;
