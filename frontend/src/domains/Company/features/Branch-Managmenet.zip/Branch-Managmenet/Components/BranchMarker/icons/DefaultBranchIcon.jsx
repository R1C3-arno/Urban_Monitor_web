const DefaultBranchIcon = () => {
    return (
        <div className="branch-icon">
            🏬
        </div>
    );
};

export default DefaultBranchIcon;
