import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080';

/**
 * ✅ DSA Service - UPDATED FOR NEW BACKEND API
 *
 * Updated endpoints:
 * - /api/admin/* - System admin (seed, clear, stats)
 * - /api/traffic/analysis/* - Blackspots, nearest incidents
 * - /api/traffic/graph/* - Graph nodes, edges, stats
 * - /api/traffic/map/* - Traffic map data
 * - /citizen/routes/* - Pathfinding
 * - /api/reports/* - Report management
 */
class DSAService {
    constructor() {
        this.client = axios.create({
            baseURL: API_BASE_URL,
            timeout: 400000,
            headers: { 'Content-Type': 'application/json' }
        });

        // ✅ Better error handling
        this.client.interceptors.response.use(
            res => res,
            err => {
                const errorMsg = this._extractErrorMessage(err);
                console.error('❌ API Error:', errorMsg);
                err.readableMessage = errorMsg;
                return Promise.reject(err);
            }
        );
    }

    /**
     * Extract readable error message
     */
    _extractErrorMessage(err) {
        if (err.response?.data?.error) {
            return err.response.data.error;
        }
        if (err.response?.data?.message) {
            return err.response.data.message;
        }
        if (err.response?.status) {
            const statusMessages = {
                400: 'Bad Request',
                401: 'Unauthorized',
                403: 'Forbidden',
                404: 'Not Found',
                500: 'Internal Server Error',
                503: 'Service Unavailable'
            };
            return statusMessages[err.response.status] || `HTTP ${err.response.status}`;
        }
        if (err.request && !err.response) {
            return 'Network Error - Server not responding';
        }
        return err.message || 'Unknown error occurred';
    }

    // ═══════════════════════════════════════════════════════════
    // ADMIN API - /api/admin/*
    // ═══════════════════════════════════════════════════════════

    /**
     * ✅ Seed enhanced graph
     * POST /api/admin/seed?nodes=300
     */
    async seedEnhancedGraph(nodeCount = 300) {
        try {
            const res = await this.client.post('/api/admin/seed', null, {
                params: { nodes: nodeCount }
            });
            console.log('✅ Graph seeded:', res.data);
            return res.data;
        } catch (err) {
            throw new Error(`Seed failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Seed simple graph (alias for seedEnhancedGraph)
     */
    async seedSimpleGraph(nodeCount = 100) {
        return await this.seedEnhancedGraph(nodeCount);
    }

    /**
     * ✅ Clear all data
     * DELETE /api/admin/data/clear
     */
    async clearAllData() {
        try {
            const res = await this.client.delete('/api/admin/data/clear');
            return res.data;
        } catch (err) {
            throw new Error(`Clear data failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get system statistics
     * GET /api/admin/stats
     */
    async getSystemStats() {
        try {
            const res = await this.client.get('/api/admin/stats');
            return res.data;
        } catch (err) {
            throw new Error(`System stats failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Health check
     * GET /api/admin/health
     */
    async healthCheck() {
        try {
            const res = await this.client.get('/api/admin/health');
            return res.data;
        } catch (err) {
            throw new Error(`Health check failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Clear route cache
     * POST /api/admin/cache/clear
     */
    async clearCache() {
        try {
            const res = await this.client.post('/api/admin/cache/clear');
            return res.data;
        } catch (err) {
            throw new Error(`Clear cache failed: ${err.readableMessage || err.message}`);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // TRAFFIC ANALYSIS API - /api/traffic/analysis/*
    // ═══════════════════════════════════════════════════════════

    /**
     * ✅ Get blackspots
     * GET /api/traffic/analysis/blackspots?radiusKm=1.1&minIncidents=3
     */
    async getBlackspots(radiusKm = 1.1, minIncidents = 3) {
        try {
            const res = await this.client.get('/api/traffic/analysis/blackspots', {
                params: { radiusKm, minIncidents }
            });
            return res.data;
        } catch (err) {
            throw new Error(`Blackspots failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get nearest incidents (KNN)
     * GET /api/traffic/analysis/nearest?lat=10.77&lng=106.69&k=5
     */
    async getNearestIncidents(lat = 10.77, lng = 106.69, k = 5) {
        try {
            const res = await this.client.get('/api/traffic/analysis/nearest', {
                params: { lat, lng, k }
            });
            return res.data?.results || [];
        } catch (err) {
            console.warn('⚠️ Nearest incidents failed:', err.readableMessage);
            return [];
        }
    }

    // ═══════════════════════════════════════════════════════════
    // TRAFFIC GRAPH API - /api/traffic/graph/*
    // ═══════════════════════════════════════════════════════════

    /**
     * ✅ Get graph nodes
     * GET /api/traffic/graph/nodes
     */
    async getGraphNodes() {
        try {
            const res = await this.client.get('/api/traffic/graph/nodes');
            return res.data;
        } catch (err) {
            throw new Error(`Graph nodes failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get graph edges
     * GET /api/traffic/graph/edges
     */
    async getGraphEdges() {
        try {
            const res = await this.client.get('/api/traffic/graph/edges');
            return res.data;
        } catch (err) {
            throw new Error(`Graph edges failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get graph statistics
     * GET /api/traffic/graph/stats
     */
    async getGraphStats() {
        try {
            const res = await this.client.get('/api/traffic/graph/stats');
            return res.data;
        } catch (err) {
            throw new Error(`Graph stats failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Get node by ID
     * GET /api/traffic/graph/nodes/{id}
     */
    async getNodeById(id) {
        try {
            const res = await this.client.get(`/api/traffic/graph/nodes/${id}`);
            return res.data;
        } catch (err) {
            throw new Error(`Get node failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Alias for getGraphNodes
     */
    async getAllNodes() {
        return await this.getGraphNodes();
    }

    /**
     * Get graph data (nodes list wrapped in object)
     */
    async getGraphData() {
        try {
            const nodes = await this.getGraphNodes();
            return { nodes: nodes || [] };
        } catch (err) {
            throw new Error(`Graph data failed: ${err.readableMessage || err.message}`);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // TRAFFIC MAP API - /api/traffic/map/*
    // ═══════════════════════════════════════════════════════════

    /**
     * ✅ Get traffic map data (all incidents)
     * GET /api/traffic/map
     */
    async getTrafficMap() {
        try {
            const res = await this.client.get('/api/traffic/map');
            return res.data;
        } catch (err) {
            throw new Error(`Traffic map failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get incidents in bounds
     * GET /api/traffic/map/bounds?minLat=&maxLat=&minLng=&maxLng=
     */
    async getIncidentsInBounds(minLat, maxLat, minLng, maxLng) {
        try {
            const res = await this.client.get('/api/traffic/map/bounds', {
                params: { minLat, maxLat, minLng, maxLng }
            });
            return res.data;
        } catch (err) {
            throw new Error(`Incidents in bounds failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get incident by ID
     * GET /api/traffic/map/incident/{id}
     */
    async getIncidentById(id) {
        try {
            const res = await this.client.get(`/api/traffic/map/incident/${id}`);
            return res.data;
        } catch (err) {
            throw new Error(`Get incident failed: ${err.readableMessage || err.message}`);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // ROUTE API - /citizen/routes/*
    // ═══════════════════════════════════════════════════════════

    /**
     * ✅ Find shortest path
     * GET /citizen/routes/find?start=1&end=20&algorithm=dijkstra
     */
    async findRoute(startId, endId, algorithm = 'dijkstra') {
        try {
            const res = await this.client.get('/citizen/routes/find', {
                params: {
                    start: startId,
                    end: endId,
                    algorithm: algorithm.toLowerCase()
                },
                validateStatus: (status) => status >= 200 && status < 500
            });

            const data = res.data;

            if (data.success === false || data.error) {
                const error = new Error(data.error || 'Route not found');
                error.isRouteNotFound = true;
                error.backendData = data;
                throw error;
            }

            return data;

        } catch (err) {
            if (err.isRouteNotFound) {
                throw err;
            }
            throw new Error(`Route finding failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get farthest node pair
     * GET /citizen/routes/farthest-pair
     */
    async getFarthestPair() {
        try {
            const res = await this.client.get('/citizen/routes/farthest-pair');
            return res.data;
        } catch (err) {
            throw new Error(`Farthest pair failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * ✅ Get available algorithms
     * GET /citizen/routes/algorithms
     */
    async getAvailableAlgorithms() {
        try {
            const res = await this.client.get('/citizen/routes/algorithms');
            return res.data;
        } catch (err) {
            throw new Error(`Get algorithms failed: ${err.readableMessage || err.message}`);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // REPORT API - /api/reports/*
    // ═══════════════════════════════════════════════════════════

    /**
     * Submit report
     * POST /api/reports
     */
    async submitReport(reportData) {
        try {
            const res = await this.client.post('/api/reports', reportData);
            return res.data;
        } catch (err) {
            throw new Error(`Submit report failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Get pending reports
     * GET /api/reports/pending
     */
    async getPendingReports() {
        try {
            const res = await this.client.get('/api/reports/pending');
            return res.data;
        } catch (err) {
            throw new Error(`Get reports failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Approve report
     * POST /api/reports/{id}/approve?reviewer=Admin
     */
    async approveReport(reportId, reviewer = 'Admin') {
        try {
            const res = await this.client.post(
                `/api/reports/${reportId}/approve`,
                null,
                { params: { reviewer } }
            );
            return res.data;
        } catch (err) {
            throw new Error(`Approve report failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Reject report
     * POST /api/reports/{id}/reject?reviewer=Admin
     */
    async rejectReport(reportId, reviewer = 'Admin') {
        try {
            const res = await this.client.post(
                `/api/reports/${reportId}/reject`,
                null,
                { params: { reviewer } }
            );
            return res.data;
        } catch (err) {
            throw new Error(`Reject report failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Undo last action
     * POST /api/reports/undo
     */
    async undoLastAction() {
        try {
            const res = await this.client.post('/api/reports/undo');
            return res.data;
        } catch (err) {
            throw new Error(`Undo failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Redo last action
     * POST /api/reports/redo
     */
    async redoLastAction() {
        try {
            const res = await this.client.post('/api/reports/redo');
            return res.data;
        } catch (err) {
            throw new Error(`Redo failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Get command history
     * GET /api/reports/command-history
     */
    async getCommandHistory() {
        try {
            const res = await this.client.get('/api/reports/command-history');
            return res.data;
        } catch (err) {
            throw new Error(`Command history failed: ${err.readableMessage || err.message}`);
        }
    }

    /**
     * Get report by ID
     * GET /api/reports/{id}
     */
    async getReportById(id) {
        try {
            const res = await this.client.get(`/api/reports/${id}`);
            return res.data;
        } catch (err) {
            throw new Error(`Get report failed: ${err.readableMessage || err.message}`);
        }
    }
}

// Export singleton instance
export const dsaService = new DSAService();
export default dsaService;
