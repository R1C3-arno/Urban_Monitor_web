import { SEVERITY_COLORS, INCIDENT_TYPES } from "../Config/incidentConfig";

/**
 * Incident Model
 * Domain model for traffic incident
 */
export class Incident {
    constructor(data = {}) {
        this.id = data.id || null;
        this.title = data.title || "";
        this.description = data.description || "";
        this.lat = data.lat || 0;
        this.lng = data.lng || 0;
        this.level = data.level || "LOW";
        this.type = data.type || "ACCIDENT";
        this.image = data.image || null;
        this.timestamp = data.timestamp || Date.now();
        this.reporter = data.reporter || "Anonymous";
        this.status = data.status || "PENDING";
    }

    /**
     * Get coordinates as [lng, lat] for Mapbox
     */
    get coords() {
        return [this.lng, this.lat];
    }

    /**
     * Get marker color based on severity
     */
    getMarkerColor() {
        return SEVERITY_COLORS[this.level] || SEVERITY_COLORS.LOW;
    }

    /**
     * Get icon based on type
     */
    getIcon() {
        return INCIDENT_TYPES[this.type]?.icon || "⚠️";
    }

    /**
     * Get type label
     */
    getTypeLabel() {
        return INCIDENT_TYPES[this.type]?.label || "Không xác định";
    }

    /**
     * Get formatted timestamp
     */
    getFormattedTime() {
        return new Date(this.timestamp).toLocaleString("vi-VN");
    }

    /**
     * Check if recent (last 24h)
     */
    isRecent() {
        return Date.now() - this.timestamp < 24 * 60 * 60 * 1000;
    }

    /**
     * Convert to JSON
     */
    toJSON() {
        return {
            id: this.id,
            title: this.title,
            description: this.description,
            lat: this.lat,
            lng: this.lng,
            level: this.level,
            type: this.type,
            image: this.image,
            timestamp: this.timestamp,
            reporter: this.reporter,
            status: this.status,
            coords: this.coords,
            icon: this.getIcon(),
            color: this.getMarkerColor(),
        };
    }

    /**
     * Create from API response
     */
    static fromAPI(data) {
        return new Incident(data);
    }
}

export default Incident;
