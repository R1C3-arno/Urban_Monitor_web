import React from "react";
import { INCIDENT_TYPES, SEVERITY_COLORS } from "../../Config/incidentConfig";
import "./IncidentPopUp.css";

/**
 * IncidentPopUp Component
 * Shows incident details
 */
export const IncidentPopUp = ({ data }) => {
    if (!data) return null;

    const typeInfo = INCIDENT_TYPES[data.type] || { icon: "⚠️", label: "Không xác định" };
    const severityColor = SEVERITY_COLORS[data.level] || SEVERITY_COLORS.LOW;

    return (
        <div className="incident-popup">
            <div className="incident-popup-header">
                <span className="incident-icon">{typeInfo.icon}</span>
                <h3>{data.title}</h3>
            </div>

            <div className="incident-popup-body">
                <p className="description">{data.description}</p>

                <div className="meta-row">
                    <span className="label">Loại:</span>
                    <span className="value">{typeInfo.label}</span>
                </div>

                <div className="meta-row">
                    <span className="label">Mức độ:</span>
                    <span className="severity-badge" style={{ backgroundColor: severityColor }}>
                        {data.level}
                    </span>
                </div>

                <div className="meta-row">
                    <span className="label">Thời gian:</span>
                    <span className="value">
                        {new Date(data.timestamp).toLocaleString("vi-VN")}
                    </span>
                </div>

                <div className="meta-row">
                    <span className="label">Trạng thái:</span>
                    <span className={`status status-${data.status?.toLowerCase()}`}>
                        {data.status}
                    </span>
                </div>

                {data.image && (
                    <div className="incident-image">
                        <img src={data.image} alt={data.title} />
                    </div>
                )}
            </div>
        </div>
    );
};

export default IncidentPopUp;
