const FactoryIcon = () => {
    return (
        <div className="branch-icon">
            🏭
        </div>
    );
};

export default FactoryIcon;
