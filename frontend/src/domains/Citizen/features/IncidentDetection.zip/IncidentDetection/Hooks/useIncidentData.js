/**
 * useIncidentData Hook
 * Orchestrates incident data fetching from backend
 * NO MOCK DATA - only fetches from API
 */

import { useState, useEffect, useCallback, useMemo } from "react";
import { incidentService } from "../Services/IncidentService";
import {
    mapToIncidents,
    mapIncidentsToMarkers,
    mapToZones,
    mapZonesToCircles,
} from "../Mappers/incidentMapper";
import { ERROR_MESSAGES } from "../Config/incidentConfig";

/**
 * Custom hook for incident data management
 * @param {Object} options
 * @param {boolean} options.autoFetch - Auto-fetch on mount
 * @param {Function} options.onIncidentClick - Callback when incident clicked
 */
export const useIncidentData = ({
    autoFetch = true,
    onIncidentClick = null,
} = {}) => {
    // ==================== STATE ====================
    const [incidents, setIncidents] = useState([]);
    const [zones, setZones] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [meta, setMeta] = useState(null);

    // Stable callback reference
    const stableOnIncidentClick = useCallback(
        (incident) => {
            onIncidentClick?.(incident);
        },
        [onIncidentClick]
    );

    // ==================== FETCH DATA ====================
    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            console.log("📥 Fetching incidents from backend...");
            const rawData = await incidentService.fetchIncidents();

            // Transform data through mappers
            const incidentModels = mapToIncidents(rawData);
            const zoneModels = mapToZones(incidentModels);

            setIncidents(incidentModels);
            setZones(zoneModels);
            setMeta(rawData.meta);

            console.log("✅ Incidents loaded:", {
                incidents: incidentModels.length,
                zones: zoneModels.length,
            });
        } catch (err) {
            console.error("❌ Error fetching incidents:", err);
            setError(err.message || ERROR_MESSAGES.LOAD_FAILED);
            setIncidents([]);
            setZones([]);
        } finally {
            setLoading(false);
        }
    }, []);

    // ==================== MEMOIZED DERIVED DATA ====================
    const markers = useMemo(() => {
        return mapIncidentsToMarkers(incidents, stableOnIncidentClick);
    }, [incidents, stableOnIncidentClick]);

    const circles = useMemo(() => {
        return mapZonesToCircles(zones);
    }, [zones]);

    // ==================== AUTO FETCH ON MOUNT ====================
    useEffect(() => {
        if (autoFetch) {
            fetchData();
        }
    }, [autoFetch, fetchData]);

    // ==================== FETCH INCIDENT BY ID ====================
    const fetchIncidentById = useCallback(async (id) => {
        try {
            const rawData = await incidentService.fetchIncidentById(id);
            return mapToIncidents({ markers: [rawData] })[0];
        } catch (err) {
            console.error(`❌ Error fetching incident ${id}:`, err);
            throw err;
        }
    }, []);

    // ==================== REFRESH ====================
    const refresh = useCallback(() => {
        console.log("🔄 Refreshing incident data...");
        return fetchData();
    }, [fetchData]);

    // ==================== PUBLIC API ====================
    return {
        // Data
        incidents,
        zones,
        markers,
        circles,
        meta,

        // State
        loading,
        error,
        isReady: !loading && !error,

        // Methods
        refresh,
        fetchIncidentById,

        // Meta
        dataSourceName: incidentService.getName(),
    };
};

export default useIncidentData;
