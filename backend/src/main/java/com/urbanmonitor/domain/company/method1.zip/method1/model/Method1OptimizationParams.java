package com.urbanmonitor.domain.company.method1.model;

import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Method1OptimizationParams {
    private double demand;
    private double pMin;
    private double pMax;
    private double av0;
    private double a0;
    private double ct;
    private double sigma;
    private double rho;
    private double hb;
    private double hv;
    private double pi;
    private double xi1;
    private double xi2;
    private double b1;
    private double b2;
    private double theta0;
    private double tt;
    private List<Double> aList;
    private List<Double> bList;
    private List<Double> cList;
}