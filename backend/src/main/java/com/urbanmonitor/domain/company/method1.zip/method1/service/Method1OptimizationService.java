package com.urbanmonitor.domain.company.method1.service;

import com.urbanmonitor.domain.company.method1.model.Method1OptimizationParams;
import com.urbanmonitor.domain.company.method1.model.Method1OptimizationResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Method1 Optimization Service
 * Simplified two-echelon supply chain optimization
 */
@Slf4j
@Service
public class Method1OptimizationService {

    private final Method1OptimizationEngine engine;

    public Method1OptimizationService() {
        this.engine = new Method1OptimizationEngine();
    }

    /**
     * Run optimization for a branch
     */
    public Method1OptimizationResult optimize(Method1OptimizationParams params) {
        log.info("📡 Method1 Optimize Request - Demand: {}", params.getDemand());

        try {
            Method1OptimizationResult result = engine.optimize(params);

            if (result != null) {
                log.info("✅ Optimization Success - TC: {}", result.getTc());
                return result;
            } else {
                log.warn("⚠️ Optimization returned null");
                return null;
            }
        } catch (Exception e) {
            log.error("❌ Optimization Error: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * Get default parameters for testing
     */
    public Method1OptimizationParams getDefaultParams() {
        return Method1OptimizationParams.builder()
                .demand(600.0)
                .pMin(700.0)
                .pMax(1200.0)
                .av0(400.0)
                .a0(150.0)
                .ct(100.0)
                .sigma(5.0)
                .rho(1.0)
                .hb(19.234)
                .hv(1.7)
                .pi(80.0)
                .xi1(1.0 / 300.0)
                .xi2(1.0 / 300.0)
                .b1(10000.0)
                .b2(20.0)
                .theta0(0.0002)
                .tt(1.9)
                .aList(java.util.List.of(0.1, 0.15, 0.1))
                .bList(java.util.List.of(0.05, 0.08, 0.04))
                .cList(java.util.List.of(10.0, 30.0, 70.0))
                .build();
    }
}