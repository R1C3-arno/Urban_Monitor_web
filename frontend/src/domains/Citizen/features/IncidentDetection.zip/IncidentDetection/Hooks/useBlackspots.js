/**
 * useBlackspots Hook
 * Fetches blackspot data from backend
 */

import { useState, useCallback } from "react";
import { incidentService } from "../Services/IncidentService";
import { mapToBlackspots, mapBlackspotsToCircles } from "../Mappers/incidentMapper";
import { BLACKSPOT_CONFIG, ERROR_MESSAGES } from "../Config/incidentConfig";

export const useBlackspots = () => {
    const [blackspots, setBlackspots] = useState([]);
    const [circles, setCircles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [parameters, setParameters] = useState(null);

    /**
     * Detect blackspots from backend
     */
    const detectBlackspots = useCallback(
        async (
            radiusKm = BLACKSPOT_CONFIG.DEFAULT_RADIUS_KM,
            minIncidents = BLACKSPOT_CONFIG.DEFAULT_MIN_INCIDENTS
        ) => {
            try {
                setLoading(true);
                setError(null);

                console.log(`🔍 Detecting blackspots (radius=${radiusKm}km, min=${minIncidents})...`);
                const rawData = await incidentService.fetchBlackspots(radiusKm, minIncidents);

                const blackspotModels = mapToBlackspots(rawData);
                const circleData = mapBlackspotsToCircles(blackspotModels);

                setBlackspots(blackspotModels);
                setCircles(circleData);
                setParameters(rawData.parameters);

                console.log("✅ Blackspots detected:", blackspotModels.length);
                return blackspotModels;
            } catch (err) {
                console.error("❌ Blackspot detection failed:", err);
                setError(err.message || ERROR_MESSAGES.BLACKSPOT_FAILED);
                return [];
            } finally {
                setLoading(false);
            }
        },
        []
    );

    /**
     * Clear blackspots
     */
    const clearBlackspots = useCallback(() => {
        setBlackspots([]);
        setCircles([]);
        setParameters(null);
        setError(null);
    }, []);

    return {
        blackspots,
        circles,
        loading,
        error,
        parameters,
        detectBlackspots,
        clearBlackspots,
        hasBlackspots: blackspots.length > 0,
    };
};

export default useBlackspots;
