package com.urbanmonitor.domain.company.method1.service;

import com.urbanmonitor.domain.company.method1.algorithm.BuyerCostCalculator;
import com.urbanmonitor.domain.company.method1.algorithm.CostCalculator;
import com.urbanmonitor.domain.company.method1.algorithm.VendorCostCalculator;
import com.urbanmonitor.domain.company.method1.model.Method1OptimizationParams;
import com.urbanmonitor.domain.company.method1.model.Method1OptimizationResult;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * Method1: Two-Echelon Supply Chain Optimization
 * Simplified + Fast implementation
 */
@Slf4j
public class Method1OptimizationEngine {

    private final CostCalculator vendorCalc;
    private final CostCalculator buyerCalc;
    private static final int MAX_ITER = 100;

    public Method1OptimizationEngine() {
        this.vendorCalc = new VendorCostCalculator();
        this.buyerCalc = new BuyerCostCalculator();
    }

    /**
     * Main optimization entry point
     */
    public Method1OptimizationResult optimize(Method1OptimizationParams params) {
        log.info("🚀 Starting Method1 optimization");

        if (Double.isNaN(params.getDemand()) || params.getDemand() <= 0) {
            log.error("❌ Invalid params - Demand: {}", params.getDemand());
            return null;
        }

        // Initial values
        double q = 30.0;
        double p = (params.getPMin() + params.getPMax()) / 2;
        double k1 = 2.0;
        double av = params.getAv0() / 2;
        double theta = params.getTheta0() / 2;
        int n = 5;
        double ts = 0.15;

        double bestTc = Double.MAX_VALUE;
        Method1OptimizationResult bestResult = null;

        // Compute setup time list
        List<Double> tsList = computeTsList(params);
        log.info("📊 Setup times count: {}", tsList.size());

        // Iterate through each setup time
        for (double tsVal : tsList) {
            double crTs = computeCrashingCost(tsVal, params);

            // Fast iteration
            for (int iter = 0; iter < MAX_ITER; iter++) {
                // Update variables
                q = Math.max(5.0, q * 0.99 + computeOptimalQ(q, p, n, k1, params) * 0.01);
                p = Math.max(params.getPMin(), Math.min(params.getPMax(),
                        p * 1.01 + computeOptimalP(q, p, n, params) * -0.01));
                k1 = Math.max(0.5, k1 * 0.99 + computeOptimalK1(q, p, n, tsVal, params) * 0.01);
                av = Math.max(params.getAv0() * 0.01, Math.min(params.getAv0(),
                        av * 0.99 + computeOptimalAv(q, params) * 0.01));
                theta = Math.max(params.getTheta0() * 0.01, Math.min(params.getTheta0(),
                        theta * 0.99 + computeOptimalTheta(q, n, params) * 0.01));

                // Check every 10 iterations
                if (iter % 10 == 0) {
                    double tc = computeTotalCost(q, p, n, k1, av, theta, tsVal, crTs, params);
                    if (tc < bestTc) {
                        bestTc = tc;
                        bestResult = Method1OptimizationResult.builder()
                                .n(n)
                                .q(q)
                                .p(p)
                                .k1(k1)
                                .av(av)
                                .theta(theta)
                                .ts(tsVal)
                                .tc(tc)
                                .build();

                        log.debug("✅ Improved TC: {}", Math.round(tc * 100.0) / 100.0);
                    }
                }
            }
        }

        if (bestResult != null) {
            log.info("✅ Optimization complete - TC: {}", Math.round(bestResult.getTc() * 100.0) / 100.0);
        }

        return bestResult;
    }

    /**
     * Compute total cost (vendor + buyer)
     */
    private double computeTotalCost(double q, double p, int n, double k1,
                                    double av, double theta, double ts, double crTs,
                                    Method1OptimizationParams params) {
        double vendorCost = vendorCalc.calculate(q, p, n, k1, av, theta, ts, params);
        double buyerCost = buyerCalc.calculate(q, p, n, k1, av, theta, ts, params);
        return vendorCost + buyerCost;
    }

    /**
     * Compute valid setup times
     */
    private List<Double> computeTsList(Method1OptimizationParams params) {
        List<Double> tsList = new ArrayList<>();
        List<Double> aList = params.getAList();
        List<Double> bList = params.getBList();

        int m = aList.size();
        double tsMax = aList.stream().mapToDouble(Double::doubleValue).sum();
        double tsMin = bList.stream().mapToDouble(Double::doubleValue).sum();

        for (int j = 1; j <= m; j++) {
            double sumA = 0;
            for (int i = j; i < m; i++) {
                sumA += aList.get(i);
            }

            double sumB = 0;
            for (int i = 0; i < j; i++) {
                sumB += bList.get(i);
            }

            double tsJ = sumA - sumB;

            if (tsJ >= tsMin && tsJ <= tsMax) {
                tsList.add(tsJ);
            }
        }

        return tsList.isEmpty() ? List.of(tsMax / 2) : tsList;
    }

    /**
     * Compute crashing cost
     */
    private double computeCrashingCost(double ts, Method1OptimizationParams params) {
        double tsMax = params.getAList().stream().mapToDouble(Double::doubleValue).sum();
        double avgC = params.getCList().stream().mapToDouble(Double::doubleValue).average().orElse(1.0);
        return (tsMax - ts) * avgC;
    }

    /**
     * Compute optimal Q using simplified formula
     */
    private double computeOptimalQ(double q, double p, int n, double k1, Method1OptimizationParams params) {
        return Math.sqrt(2 * params.getDemand() * (params.getA0() + n * params.getCt()) / params.getHb());
    }

    /**
     * Compute optimal P
     */
    private double computeOptimalP(double q, double p, int n, Method1OptimizationParams params) {
        return Math.sqrt(params.getDemand() / (2 * params.getXi2()));
    }

    /**
     * Compute optimal k1
     */
    private double computeOptimalK1(double q, double p, int n, double ts, Method1OptimizationParams params) {
        double tSafe = Math.max(ts + q / p, 1e-10);
        return params.getSigma() * Math.sqrt(tSafe) / Math.max(tSafe, 1e-10);
    }

    /**
     * Compute optimal Av
     */
    private double computeOptimalAv(double q, Method1OptimizationParams params) {
        return Math.sqrt(params.getB2() * params.getDemand() * q / 2);
    }

    /**
     * Compute optimal theta
     */
    private double computeOptimalTheta(double q, int n, Method1OptimizationParams params) {
        return params.getB1() / Math.max(params.getRho() * params.getDemand() * q * n / 2, 1e-10);
    }
}