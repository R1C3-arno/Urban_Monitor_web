import axios from "axios";
import { INCIDENT_API_CONFIG } from "../Config/incidentConfig";

const { BASE_URL, ENDPOINTS, TIMEOUT } = INCIDENT_API_CONFIG;

/**
 * IncidentService
 * API Service for Incident Detection - ONLY calls backend, NO mock data
 */
class IncidentService {
    constructor() {
        this.client = axios.create({
            baseURL: BASE_URL,
            timeout: TIMEOUT,
            headers: { "Content-Type": "application/json" },
        });

        this.client.interceptors.response.use(
            (res) => res,
            (err) => {
                const errorMsg = this._extractError(err);
                console.error("❌ IncidentService Error:", errorMsg);
                err.readableMessage = errorMsg;
                return Promise.reject(err);
            }
        );
    }

    _extractError(err) {
        if (err.response?.data?.error) return err.response.data.error;
        if (err.response?.data?.message) return err.response.data.message;
        if (err.request && !err.response) return "Network Error - Server not responding";
        return err.message || "Unknown error";
    }

    /**
     * Get service name
     */
    getName() {
        return "IncidentAPIService";
    }

    // ═══════════════════════════════════════════════════════════
    // TRAFFIC MAP API - /api/traffic/map/*
    // ═══════════════════════════════════════════════════════════

    /**
     * GET /api/traffic/map - Get all validated incidents
     */
    async fetchIncidents() {
        try {
            const res = await this.client.get(ENDPOINTS.GET_ALL_INCIDENTS);
            console.log("✅ Fetched incidents:", res.data?.markers?.length || 0);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch incidents failed: ${err.readableMessage}`);
        }
    }

    /**
     * GET /api/traffic/map/bounds - Get incidents in bounds
     */
    async fetchIncidentsInBounds(minLat, maxLat, minLng, maxLng) {
        try {
            const res = await this.client.get(ENDPOINTS.GET_INCIDENTS_IN_BOUNDS, {
                params: { minLat, maxLat, minLng, maxLng },
            });
            return res.data;
        } catch (err) {
            throw new Error(`Fetch in bounds failed: ${err.readableMessage}`);
        }
    }

    /**
     * GET /api/traffic/map/incident/{id} - Get incident by ID
     */
    async fetchIncidentById(id) {
        try {
            const res = await this.client.get(`${ENDPOINTS.GET_INCIDENT_BY_ID}/${id}`);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch incident failed: ${err.readableMessage}`);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // ANALYSIS API - /api/traffic/analysis/*
    // ═══════════════════════════════════════════════════════════

    /**
     * GET /api/traffic/analysis/blackspots - Detect blackspots
     */
    async fetchBlackspots(radiusKm = 1.1, minIncidents = 3) {
        try {
            const res = await this.client.get(ENDPOINTS.GET_BLACKSPOTS, {
                params: { radiusKm, minIncidents },
            });
            console.log("✅ Fetched blackspots:", res.data?.blackspots?.length || 0);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch blackspots failed: ${err.readableMessage}`);
        }
    }

    /**
     * GET /api/traffic/analysis/nearest - Find K nearest incidents
     */
    async fetchNearestIncidents(lat, lng, k = 5) {
        try {
            const res = await this.client.get(ENDPOINTS.GET_NEAREST, {
                params: { lat, lng, k },
            });
            console.log("✅ Fetched nearest:", res.data?.results?.length || 0);
            return res.data;
        } catch (err) {
            console.warn("⚠️ Fetch nearest failed:", err.readableMessage);
            return { results: [], query: { lat, lng, k } };
        }
    }

    // ═══════════════════════════════════════════════════════════
    // GRAPH API - /api/traffic/graph/*
    // ═══════════════════════════════════════════════════════════

    /**
     * GET /api/traffic/graph/nodes
     */
    async fetchGraphNodes() {
        try {
            const res = await this.client.get(ENDPOINTS.GET_GRAPH_NODES);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch nodes failed: ${err.readableMessage}`);
        }
    }

    /**
     * GET /api/traffic/graph/edges
     */
    async fetchGraphEdges() {
        try {
            const res = await this.client.get(ENDPOINTS.GET_GRAPH_EDGES);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch edges failed: ${err.readableMessage}`);
        }
    }

    /**
     * GET /api/traffic/graph/stats
     */
    async fetchGraphStats() {
        try {
            const res = await this.client.get(ENDPOINTS.GET_GRAPH_STATS);
            return res.data;
        } catch (err) {
            throw new Error(`Fetch stats failed: ${err.readableMessage}`);
        }
    }
}

// Export singleton
export const incidentService = new IncidentService();
export default incidentService;
