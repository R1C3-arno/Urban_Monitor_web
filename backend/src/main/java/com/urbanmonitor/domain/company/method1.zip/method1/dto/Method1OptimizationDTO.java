package com.urbanmonitor.domain.company.method1.dto;

import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Method1OptimizationDTO {
    private Long branchId;
    private Double demand;
    private Double pMin;
    private Double pMax;
    private Double av0;
    private Double a0;
    private Double ct;
    private Double sigma;
    private Double rho;
    private Double hb;
    private Double hv;
    private Double pi;
    private Double xi1;
    private Double xi2;
    private Double b1;
    private Double b2;
    private Double theta0;
    private Double tt;
    private List<Double> aList;
    private List<Double> bList;
    private List<Double> cList;
}