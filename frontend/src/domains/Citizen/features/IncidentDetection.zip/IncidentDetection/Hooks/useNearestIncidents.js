/**
 * useNearestIncidents Hook
 * KNN algorithm - finds K nearest incidents from backend
 */

import { useState, useCallback } from "react";
import { incidentService } from "../Services/IncidentService";
import { KNN_CONFIG, ERROR_MESSAGES } from "../Config/incidentConfig";

export const useNearestIncidents = () => {
    const [nearestIncidents, setNearestIncidents] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [query, setQuery] = useState(null);

    /**
     * Find K nearest incidents to a location
     */
    const findNearest = useCallback(async (lat, lng, k = KNN_CONFIG.DEFAULT_K) => {
        try {
            setLoading(true);
            setError(null);

            console.log(`🔍 Finding ${k} nearest incidents to [${lat}, ${lng}]...`);
            const rawData = await incidentService.fetchNearestIncidents(lat, lng, k);

            setNearestIncidents(rawData.results || []);
            setQuery(rawData.query);

            console.log("✅ Found nearest:", rawData.results?.length || 0);
            return rawData.results || [];
        } catch (err) {
            console.error("❌ KNN search failed:", err);
            setError(err.message || ERROR_MESSAGES.KNN_FAILED);
            return [];
        } finally {
            setLoading(false);
        }
    }, []);

    /**
     * Clear results
     */
    const clearNearest = useCallback(() => {
        setNearestIncidents([]);
        setQuery(null);
        setError(null);
    }, []);

    return {
        nearestIncidents,
        loading,
        error,
        query,
        findNearest,
        clearNearest,
        hasResults: nearestIncidents.length > 0,
    };
};

export default useNearestIncidents;
