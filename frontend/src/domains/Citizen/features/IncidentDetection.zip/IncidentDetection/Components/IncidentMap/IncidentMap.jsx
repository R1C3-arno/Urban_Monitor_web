import React, { useState, useEffect, useRef } from "react";

// ⚠️ ADJUST THESE IMPORT PATHS TO MATCH YOUR PROJECT STRUCTURE
import Map from "../../../../../../shared/Components/Map/BaseMap/Map.jsx";
import MapPopUp from "../../../../../../shared/Components/Map/MapPopUp/PopUp.jsx";

import IncidentPopUp from "../IncidentPopUp/IncidentPopUp.jsx";
import IncidentCircle from "./IncidentCircle.jsx";
import { useIncidentData } from "../../Hooks/useIncidentData.js";
import { useBlackspots } from "../../Hooks/useBlackspots.js";
import { useNearestIncidents } from "../../Hooks/useNearestIncidents.js";
import BlackspotLayer from "../BlackspotLayer/BlackspotLayer.jsx";
import NearestIncidentsLayer from "../NearestIncidents/NearestIncidentsLayer.jsx";

import {
    INCIDENT_MAP_CONFIG,
    GEOLOCATION_CONFIG,
    ERROR_MESSAGES,
} from "../../Config/incidentConfig.js";
import "./IncidentMap.css";

/**
 * IncidentMap Component
 * Main map component for Incident Detection feature
 * 
 * Features:
 * - Display all incidents as markers (from backend)
 * - Show danger zones as circles
 * - Blackspot detection
 * - KNN nearest incidents
 */
const IncidentMap = () => {
    // ==================== STATE ====================
    const [map, setMap] = useState(null);
    const [selectedIncident, setSelectedIncident] = useState(null);
    const [userLocation, setUserLocation] = useState(null);

    // Feature toggles
    const [showBlackspots, setShowBlackspots] = useState(false);
    const [showNearestFinder, setShowNearestFinder] = useState(false);

    const mapRef = useRef();

    // ==================== HOOKS - FETCH FROM BACKEND ====================
    const {
        markers,
        circles,
        loading,
        error,
        isReady,
        dataSourceName,
    } = useIncidentData({
        autoFetch: true,
        onIncidentClick: (incident) => {
            console.log("📍 Incident clicked:", incident.title);
            setSelectedIncident(incident);
        },
    });

    // ==================== EVENT HANDLERS ====================

    const handleMapClick = (e) => {
        console.log("🗺️ Map clicked:", e.lngLat);
        setSelectedIncident(null);
    };

    const handleUserLocationFound = (location) => {
        console.log("📍 User location found:", location);

        try {
            setUserLocation(location);

            if (map && map.loaded && typeof map.flyTo === "function") {
                map.flyTo({
                    center: [location.lng, location.lat],
                    zoom: 15,
                    duration: 2000,
                    essential: true,
                });
            }
        } catch (error) {
            console.error("❌ Error in handleUserLocationFound:", error);
        }
    };

    const handleGeolocationError = (errorMsg) => {
        console.error("❌ Geolocation error:", errorMsg);

        let message = ERROR_MESSAGES.GEOLOCATION_UNAVAILABLE;

        if (typeof errorMsg === "string") {
            if (errorMsg.includes("denied")) {
                message = ERROR_MESSAGES.GEOLOCATION_DENIED;
            } else if (errorMsg.includes("timeout")) {
                message = ERROR_MESSAGES.GEOLOCATION_TIMEOUT;
            }
        }

        alert(message);
    };

    const handlePopupClose = () => {
        console.log("❌ Closing popup");
        setSelectedIncident(null);
    };

    // ==================== RENDER ====================

    if (loading) {
        return (
            <div className="incident-map-loading">
                <p>⏳ Đang tải dữ liệu sự cố...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="incident-map-error">
                <p>❌ {error}</p>
                <p>Nguồn dữ liệu: {dataSourceName}</p>
            </div>
        );
    }

    return (
        <div className="incident-map">
            {/* Map Component */}
            <Map
                center={INCIDENT_MAP_CONFIG.DEFAULT_CENTER}
                zoom={INCIDENT_MAP_CONFIG.DEFAULT_ZOOM}
                markers={markers}
                getMap={setMap}
                onMapClick={handleMapClick}
                enableGeolocation={GEOLOCATION_CONFIG.ENABLED}
                geolocatePosition={GEOLOCATION_CONFIG.POSITION}
                trackUserLocation={GEOLOCATION_CONFIG.TRACK_USER}
                showAccuracyCircle={GEOLOCATION_CONFIG.SHOW_ACCURACY_CIRCLE}
                maxAccuracyRadius={GEOLOCATION_CONFIG.MAX_ACCURACY_RADIUS}
                onUserLocationFound={handleUserLocationFound}
                onGeolocationError={handleGeolocationError}
            />

            {/* Danger Zone Circles */}
            {map && circles.length > 0 && (
                <IncidentCircle map={map} data={circles} />
            )}

            {/* Popup for selected incident */}
            {selectedIncident && map && (
                <div className="map-popup-container">
                    <MapPopUp
                        map={map}
                        coords={selectedIncident.coords}
                        onClose={handlePopupClose}
                    >
                        <IncidentPopUp data={selectedIncident.toJSON()} />
                    </MapPopUp>
                </div>
            )}

            {/* Feature Control Panel */}
            <div className="incident-controls">
                <div className="controls-title">🚨 Incident Detection</div>

                <button
                    onClick={() => setShowBlackspots(!showBlackspots)}
                    className={`control-btn ${showBlackspots ? "active" : ""}`}
                >
                    🔴 Blackspots
                </button>

                <button
                    onClick={() => setShowNearestFinder(!showNearestFinder)}
                    className={`control-btn ${showNearestFinder ? "active" : ""}`}
                >
                    🔍 KNN Search
                </button>
            </div>

            {/* Blackspot Layer */}
            <BlackspotLayer visible={showBlackspots} map={map} />

            {/* Nearest Incidents Layer */}
            <NearestIncidentsLayer visible={showNearestFinder} map={map} />

            {/* Debug Info */}
            {process.env.NODE_ENV === "development" && (
                <div className="debug-info">
                    <div>📊 Data: {dataSourceName}</div>
                    <div>📍 Incidents: {markers.length}</div>
                    <div>🔴 Zones: {circles.length}</div>
                    {userLocation && (
                        <div>
                            📌 User: [{userLocation.lng.toFixed(4)}, {userLocation.lat.toFixed(4)}]
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default IncidentMap;
