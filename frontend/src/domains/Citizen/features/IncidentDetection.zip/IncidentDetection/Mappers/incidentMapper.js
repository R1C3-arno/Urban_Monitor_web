import { Incident } from "../Models/Incident";
import { Blackspot } from "../Models/Blackspot";
import { CIRCLE_CONFIG, SEVERITY_COLORS } from "../Config/incidentConfig";

/**
 * Map API response to Incident models
 */
export const mapToIncidents = (rawData) => {
    if (!rawData?.markers) return [];

    return rawData.markers.map((item) => Incident.fromAPI(item));
};

/**
 * Map Incident models to marker props for <Map />
 */
export const mapIncidentsToMarkers = (incidents, onClickCallback) => {
    if (!incidents || incidents.length === 0) return [];

    return incidents.map((incident) => ({
        id: incident.id,
        coords: incident.coords,
        color: incident.getMarkerColor(),
        size: 14,
        popup: null, // Use custom popup
        data: incident,
        onClick: () => onClickCallback?.(incident),
    }));
};

/**
 * Group incidents into zones for circle display
 */
export const mapToZones = (incidents) => {
    if (!incidents || incidents.length === 0) return [];

    // Group by approximate location (grid-based)
    const gridSize = 0.005; // ~500m
    const zoneMap = new Map();

    incidents.forEach((incident) => {
        const gridLat = Math.floor(incident.lat / gridSize) * gridSize;
        const gridLng = Math.floor(incident.lng / gridSize) * gridSize;
        const key = `${gridLat.toFixed(4)},${gridLng.toFixed(4)}`;

        if (!zoneMap.has(key)) {
            zoneMap.set(key, {
                lat: gridLat + gridSize / 2,
                lng: gridLng + gridSize / 2,
                incidents: [],
            });
        }
        zoneMap.get(key).incidents.push(incident);
    });

    // Convert to zones with severity
    return Array.from(zoneMap.values())
        .filter((zone) => zone.incidents.length >= 2) // Min 2 incidents for a zone
        .map((zone) => {
            const highCount = zone.incidents.filter((i) => i.level === "HIGH").length;
            const level = highCount >= 2 ? "HIGH" : zone.incidents.length >= 3 ? "MEDIUM" : "LOW";

            return {
                lat: zone.lat,
                lng: zone.lng,
                level,
                count: zone.incidents.length,
                radius: CIRCLE_CONFIG.RADIUS_BY_LEVEL[level],
            };
        });
};

/**
 * Map zones to circle props for TrafficCircle component
 */
export const mapZonesToCircles = (zones) => {
    if (!zones || zones.length === 0) return [];

    return zones.map((zone, index) => ({
        id: `zone-${index}`,
        center: [zone.lng, zone.lat],
        radius: zone.radius,
        color: SEVERITY_COLORS[zone.level],
        opacity: CIRCLE_CONFIG.OPACITY,
        level: zone.level,
        count: zone.count,
    }));
};

/**
 * Map API response to Blackspot models
 */
export const mapToBlackspots = (rawData) => {
    if (!rawData?.blackspots) return [];

    return rawData.blackspots.map((item) => Blackspot.fromAPI(item));
};

/**
 * Map blackspots to circle props
 */
export const mapBlackspotsToCircles = (blackspots) => {
    if (!blackspots || blackspots.length === 0) return [];

    return blackspots.map((bs, index) => ({
        id: `blackspot-${index}`,
        center: bs.coords,
        radius: bs.getRadiusMeters(),
        color: bs.getColor(),
        opacity: 0.35,
        data: bs,
    }));
};

export default {
    mapToIncidents,
    mapIncidentsToMarkers,
    mapToZones,
    mapZonesToCircles,
    mapToBlackspots,
    mapBlackspotsToCircles,
};
