package com.urbanmonitor.domain.citizen.controller;

public class AdminController {
}
