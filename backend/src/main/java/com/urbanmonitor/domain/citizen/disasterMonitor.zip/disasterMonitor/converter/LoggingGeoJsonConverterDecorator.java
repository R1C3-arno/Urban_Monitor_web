package com.urbanmonitor.domain.citizen.disasterMonitor.converter;

import com.urbanmonitor.domain.citizen.disasterMonitor.entity.DisasterZone;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * DECORATOR PATTERN - Concrete Decorator
 * 
 * Decorator thêm logging cho conversion operations.
 */
@Slf4j
public class LoggingGeoJsonConverterDecorator extends GeoJsonConverterDecorator {
    
    public LoggingGeoJsonConverterDecorator(GeoJsonConverter delegate) {
        super(delegate);
    }
    
    @Override
    public Map<String, Object> convert(List<DisasterZone> zones) {
        long startTime = System.currentTimeMillis();
        
        log.info("Starting GeoJSON conversion for {} zones", zones.size());
        
        Map<String, Object> result = delegate.convert(zones);
        
        long duration = System.currentTimeMillis() - startTime;
        
        @SuppressWarnings("unchecked")
        List<Object> features = (List<Object>) result.get("features");
        int featureCount = features != null ? features.size() : 0;
        
        log.info("GeoJSON conversion completed: {} features in {}ms", featureCount, duration);
        
        return result;
    }
}
