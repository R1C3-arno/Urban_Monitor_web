import { RISK_LEVELS } from "../Config/incidentConfig";

/**
 * Blackspot Model
 * Represents accident blackspot zone
 */
export class Blackspot {
    constructor(data = {}) {
        this.lat = data.lat || 0;
        this.lng = data.lng || 0;
        this.incidentCount = data.incidentCount || 0;
        this.severityScore = data.severityScore || 0;
        this.recentIncidents = data.recentIncidents || 0;
        this.highSeverityCount = data.highSeverityCount || 0;
        this.radiusKm = data.radiusKm || 1.0;
        this.riskLevel = data.riskLevel || "LOW";
    }

    get coords() {
        return [this.lng, this.lat];
    }

    getColor() {
        return RISK_LEVELS[this.riskLevel]?.color || RISK_LEVELS.LOW.color;
    }

    getRadiusMeters() {
        return this.radiusKm * 1000;
    }

    getSummary() {
        return `${this.incidentCount} sự cố | ${RISK_LEVELS[this.riskLevel]?.label || "Không xác định"}`;
    }

    static fromAPI(data) {
        return new Blackspot(data);
    }
}

export default Blackspot;
