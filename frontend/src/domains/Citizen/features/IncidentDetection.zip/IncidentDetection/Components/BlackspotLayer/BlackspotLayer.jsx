import React, { useEffect, useRef } from "react";
import { useBlackspots } from "../../Hooks/useBlackspots";
import * as turf from "@turf/turf";

/**
 * BlackspotLayer Component
 * Renders blackspot detection zones on map
 */
const BlackspotLayer = ({ map, visible = false }) => {
    const mapRef = useRef(map);
    const layersRef = useRef([]);
    const { blackspots, circles, detectBlackspots, clearBlackspots } = useBlackspots();

    useEffect(() => {
        mapRef.current = map;
    }, [map]);

    // Fetch blackspots when visible
    useEffect(() => {
        if (visible && blackspots.length === 0) {
            detectBlackspots();
        }
    }, [visible, blackspots.length, detectBlackspots]);

    // Draw circles when data changes
    useEffect(() => {
        if (!mapRef.current || !visible || circles.length === 0) return;

        if (!mapRef.current.isStyleLoaded()) {
            mapRef.current.once("style.load", drawBlackspots);
            return;
        }

        drawBlackspots();

        return () => cleanup();
    }, [circles, visible]);

    // Clear when hidden
    useEffect(() => {
        if (!visible) {
            cleanup();
        }
    }, [visible]);

    const drawBlackspots = () => {
        if (!mapRef.current || circles.length === 0) return;

        cleanup();

        circles.forEach((circle, index) => {
            const sourceId = `blackspot-source-${index}`;
            const fillLayerId = `blackspot-fill-${index}`;
            const lineLayerId = `blackspot-line-${index}`;
            const centerLayerId = `blackspot-center-${index}`;

            // Create circle polygon
            const circlePolygon = turf.circle(circle.center, circle.radius / 1000, {
                steps: 64,
                units: "kilometers",
            });

            // Add source
            mapRef.current.addSource(sourceId, {
                type: "geojson",
                data: circlePolygon,
            });

            // Fill layer
            mapRef.current.addLayer({
                id: fillLayerId,
                type: "fill",
                source: sourceId,
                paint: {
                    "fill-color": circle.color,
                    "fill-opacity": circle.opacity || 0.3,
                },
            });

            // Outline layer
            mapRef.current.addLayer({
                id: lineLayerId,
                type: "line",
                source: sourceId,
                paint: {
                    "line-color": circle.color,
                    "line-width": 2,
                    "line-opacity": 0.8,
                },
            });

            // Center point
            const centerSourceId = `${sourceId}-center`;
            mapRef.current.addSource(centerSourceId, {
                type: "geojson",
                data: {
                    type: "Feature",
                    geometry: {
                        type: "Point",
                        coordinates: circle.center,
                    },
                },
            });

            mapRef.current.addLayer({
                id: centerLayerId,
                type: "circle",
                source: centerSourceId,
                paint: {
                    "circle-color": circle.color,
                    "circle-radius": 8,
                    "circle-stroke-width": 3,
                    "circle-stroke-color": "#ffffff",
                },
            });

            layersRef.current.push(sourceId, fillLayerId, lineLayerId, centerSourceId, centerLayerId);
        });

        console.log(`✅ Drew ${circles.length} blackspot zones`);
    };

    const cleanup = () => {
        if (!mapRef.current) return;

        layersRef.current.forEach((id) => {
            if (mapRef.current.getLayer(id)) {
                mapRef.current.removeLayer(id);
            }
            if (mapRef.current.getSource(id)) {
                mapRef.current.removeSource(id);
            }
        });

        layersRef.current = [];
    };

    if (!visible) return null;

    return null;
};

export default BlackspotLayer;
