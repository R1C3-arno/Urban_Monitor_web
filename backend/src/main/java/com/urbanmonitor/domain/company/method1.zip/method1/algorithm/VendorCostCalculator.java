package com.urbanmonitor.domain.company.method1.algorithm;

import com.urbanmonitor.domain.company.method1.model.Method1OptimizationParams;
import lombok.extern.slf4j.Slf4j;

/**
 * Vendor side cost calculation
 */
@Slf4j
public class VendorCostCalculator implements CostCalculator {

    @Override
    public double calculate(double q, double p, int n, double k1,
                            double av, double theta, double ts,
                            Method1OptimizationParams params) {

        double cp = params.getXi1() * p + params.getXi2() / p;

        double t1 = av * params.getDemand() / (n * q);
        double t2 = params.getHv() * q / 2 * (n * (1 - params.getDemand() / p) - 1 + 2 * params.getDemand() / p);
        double t3 = params.getDemand() * cp;
        double t4 = params.getB1() * Math.log(Math.max(theta, 1e-10) / params.getTheta0());
        double t5 = params.getB2() * Math.log(params.getAv0() / Math.max(av, 1e-10));
        double t6 = params.getRho() * params.getDemand() * theta * n * q / 2;

        return t1 + t2 + t3 + t4 + t5 + t6;
    }
}