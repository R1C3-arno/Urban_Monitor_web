/**
 * Incident Detection Configuration
 * Single source of truth for all incident-related constants
 */

// ==================== MAP SETTINGS ====================
export const INCIDENT_MAP_CONFIG = {
    DEFAULT_CENTER: [106.7, 10.7], // Ho Chi Minh City
    DEFAULT_ZOOM: 13,
    MIN_ZOOM: 10,
    MAX_ZOOM: 18,
};

// ==================== GEOLOCATION SETTINGS ====================
export const GEOLOCATION_CONFIG = {
    ENABLED: true,
    POSITION: "top-right",
    TRACK_USER: false,
    SHOW_USER_LOCATION: true,
    SHOW_ACCURACY_CIRCLE: true,
    MAX_ACCURACY_RADIUS: 50,
    HIGH_ACCURACY: true,
    TIMEOUT: 10000,
    MAXIMUM_AGE: 0,
};

// ==================== SEVERITY LEVELS ====================
export const SEVERITY_LEVELS = {
    LOW: "LOW",
    MEDIUM: "MEDIUM",
    HIGH: "HIGH",
};

// ==================== COLORS BY SEVERITY ====================
export const SEVERITY_COLORS = {
    LOW: "#22C55E",      // Green
    MEDIUM: "#F59E0B",   // Amber
    HIGH: "#EF4444",     // Red
};

// ==================== INCIDENT TYPES ====================
export const INCIDENT_TYPES = {
    CAR: { icon: "🚗", label: "Ô tô", color: "#3B82F6" },
    BIKE: { icon: "🏍️", label: "Xe máy", color: "#8B5CF6" },
    ACCIDENT: { icon: "💥", label: "Tai nạn", color: "#EF4444" },
    JAM: { icon: "🚦", label: "Kẹt xe", color: "#F59E0B" },
    SLOW: { icon: "🐌", label: "Di chuyển chậm", color: "#6B7280" },
    FAST: { icon: "⚡", label: "Di chuyển nhanh", color: "#10B981" },
};

// ==================== RISK LEVELS FOR BLACKSPOTS ====================
export const RISK_LEVELS = {
    LOW: { label: "Thấp", color: "#22C55E" },
    MEDIUM: { label: "Trung bình", color: "#F59E0B" },
    HIGH: { label: "Cao", color: "#EF4444" },
    VERY_HIGH: { label: "Rất cao", color: "#7C2D12" },
};

// ==================== BLACKSPOT CONFIG ====================
export const BLACKSPOT_CONFIG = {
    DEFAULT_RADIUS_KM: 1.1,
    DEFAULT_MIN_INCIDENTS: 3,
    MAX_RADIUS_KM: 50,
    MIN_RADIUS_KM: 0.1,
};

// ==================== KNN CONFIG ====================
export const KNN_CONFIG = {
    DEFAULT_K: 5,
    MAX_K: 20,
    MIN_K: 1,
};

// ==================== API ENDPOINTS ====================
export const INCIDENT_API_CONFIG = {
    BASE_URL: "http://localhost:8080",
    ENDPOINTS: {
        // Traffic Map API
        GET_ALL_INCIDENTS: "/api/traffic/map",
        GET_INCIDENTS_IN_BOUNDS: "/api/traffic/map/bounds",
        GET_INCIDENT_BY_ID: "/api/traffic/map/incident",
        
        // Analysis API
        GET_BLACKSPOTS: "/api/traffic/analysis/blackspots",
        GET_NEAREST: "/api/traffic/analysis/nearest",
        
        // Graph API
        GET_GRAPH_NODES: "/api/traffic/graph/nodes",
        GET_GRAPH_EDGES: "/api/traffic/graph/edges",
        GET_GRAPH_STATS: "/api/traffic/graph/stats",
    },
    TIMEOUT: 30000,
};

// ==================== MARKER CONFIG ====================
export const MARKER_CONFIG = {
    SIZE_BY_SEVERITY: {
        LOW: 12,
        MEDIUM: 14,
        HIGH: 16,
    },
    OPACITY: 0.9,
    STROKE_WIDTH: 2,
    STROKE_COLOR: "#FFFFFF",
};

// ==================== CIRCLE CONFIG (for zones) ====================
export const CIRCLE_CONFIG = {
    OPACITY: 0.25,
    SEGMENTS: 64,
    RADIUS_BY_LEVEL: {
        LOW: 120,
        MEDIUM: 200,
        HIGH: 300,
    },
};

// ==================== ERROR MESSAGES ====================
export const ERROR_MESSAGES = {
    LOAD_FAILED: "Không thể tải dữ liệu sự cố",
    INVALID_DATA: "Dữ liệu không hợp lệ",
    NETWORK_ERROR: "Lỗi kết nối mạng",
    GEOLOCATION_DENIED: "Bạn đã từ chối quyền truy cập vị trí",
    GEOLOCATION_UNAVAILABLE: "Không thể xác định vị trí",
    GEOLOCATION_TIMEOUT: "Hết thời gian chờ",
    NO_INCIDENTS: "Không có sự cố nào",
    BLACKSPOT_FAILED: "Không thể phát hiện điểm đen",
    KNN_FAILED: "Không thể tìm sự cố gần nhất",
};

export default {
    INCIDENT_MAP_CONFIG,
    GEOLOCATION_CONFIG,
    SEVERITY_LEVELS,
    SEVERITY_COLORS,
    INCIDENT_TYPES,
    RISK_LEVELS,
    BLACKSPOT_CONFIG,
    KNN_CONFIG,
    INCIDENT_API_CONFIG,
    MARKER_CONFIG,
    CIRCLE_CONFIG,
    ERROR_MESSAGES,
};
