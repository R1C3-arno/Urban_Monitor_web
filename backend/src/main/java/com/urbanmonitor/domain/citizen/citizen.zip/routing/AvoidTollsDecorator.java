package com.urbanmonitor.domain.citizen.routing;

public class AvoidTollsDecorator {
}
