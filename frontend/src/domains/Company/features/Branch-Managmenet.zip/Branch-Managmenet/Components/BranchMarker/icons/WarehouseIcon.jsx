const WarehouseIcon = () => {
    return (
        <div className="branch-icon">
            📦
        </div>
    );
};

export default WarehouseIcon;
