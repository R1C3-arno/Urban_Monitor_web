package com.urbanmonitor.domain.company.method1.algorithm;

import com.urbanmonitor.domain.company.method1.dto.Method1OptimizationDTO;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class Method1Optimizer {

    private static final int MAX_ITER = 100;
    private static final double TOL = 1e-6;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class OptimizationResult {
        private Integer n;
        private Double q;
        private Double p;
        private Double k1;
        private Double av;
        private Double theta;
        private Double ts;
        private Double tc;
    }

    /**
     * Main optimization method
     */
    public static OptimizationResult optimize(Method1OptimizationDTO params) {
        log.info("🚀 Starting Method1 optimization - Demand: {}", params.getDemand());

        // Initial values
        double q = 30.0;
        double p = (params.getPMin() + params.getPMax()) / 2;
        double k1 = 2.0;
        double av = params.getAv0() / 2;
        double theta = params.getTheta0() / 2;
        int n = 5;
        double ts = 0.15;

        double bestTc = Double.MAX_VALUE;
        OptimizationResult bestResult = null;

        // Compute setup times
        List<Double> tsList = computeTsList(params);
        log.info("📊 Setup times: {}", tsList.size());

        // Iterate
        for (double tsVal : tsList) {
            for (int iter = 0; iter < MAX_ITER; iter++) {
                // Update variables
                q = Math.max(5.0, q * 0.99 + computeOptimalQ(q, p, n, params) * 0.01);
                p = Math.max(params.getPMin(), Math.min(params.getPMax(),
                        p * 1.01 + computeOptimalP(params) * -0.01));
                k1 = Math.max(0.5, k1 * 0.99 + computeOptimalK1(q, p, tsVal, params) * 0.01);
                av = Math.max(params.getAv0() * 0.01, Math.min(params.getAv0(),
                        av * 0.99 + computeOptimalAv(q, params) * 0.01));
                theta = Math.max(params.getTheta0() * 0.01, Math.min(params.getTheta0(),
                        theta * 0.99 + computeOptimalTheta(q, n, params) * 0.01));

                if (iter % 10 == 0) {
                    double tc = Method1CostCalculator.totalCost(q, p, n, k1, av, theta, tsVal, params);
                    if (tc < bestTc) {
                        bestTc = tc;
                        bestResult = OptimizationResult.builder()
                                .n(n).q(q).p(p).k1(k1).av(av)
                                .theta(theta).ts(tsVal).tc(tc)
                                .build();
                        log.debug("✅ TC improved: {}", Math.round(tc * 100.0) / 100.0);
                    }
                }
            }
        }

        if (bestResult != null) {
            log.info("✅ Optimization complete - TC: {}", Math.round(bestResult.getTc() * 100.0) / 100.0);
        }

        return bestResult;
    }

    /**
     * Compute setup time list
     */
    private static List<Double> computeTsList(Method1OptimizationDTO params) {
        List<Double> tsList = new ArrayList<>();
        List<Double> aList = params.getAList();
        List<Double> bList = params.getBList();

        int m = aList.size();
        double tsMax = aList.stream().mapToDouble(Double::doubleValue).sum();
        double tsMin = bList.stream().mapToDouble(Double::doubleValue).sum();

        for (int j = 1; j <= m; j++) {
            double sumA = 0;
            for (int i = j; i < m; i++) {
                sumA += aList.get(i);
            }

            double sumB = 0;
            for (int i = 0; i < j; i++) {
                sumB += bList.get(i);
            }

            double tsJ = sumA - sumB;
            if (tsJ >= tsMin && tsJ <= tsMax) {
                tsList.add(tsJ);
            }
        }

        return tsList.isEmpty() ? List.of(tsMax / 2) : tsList;
    }

    private static double computeOptimalQ(double q, double p, int n, Method1OptimizationDTO params) {
        return Math.sqrt(2 * params.getDemand() * (params.getA0() + n * params.getCt()) / params.getHb());
    }

    private static double computeOptimalP(Method1OptimizationDTO params) {
        return Math.sqrt(params.getDemand() / (2 * params.getXi2()));
    }

    private static double computeOptimalK1(double q, double p, double ts, Method1OptimizationDTO params) {
        double tSafe = Math.max(ts + q / p, 1e-10);
        return params.getSigma() * Math.sqrt(tSafe) / Math.max(tSafe, 1e-10);
    }

    private static double computeOptimalAv(double q, Method1OptimizationDTO params) {
        return Math.sqrt(params.getB2() * params.getDemand() * q / 2);
    }

    private static double computeOptimalTheta(double q, int n, Method1OptimizationDTO params) {
        return params.getB1() / Math.max(params.getRho() * params.getDemand() * q * n / 2, 1e-10);
    }
}