import React, { useEffect, useRef } from "react";
import * as maptilersdk from "@maptiler/sdk";
import "./BranchPopUp.css";

const BranchPopUp = ({ map, branch, onClose }) => {
    const popupRef = useRef(null);

    useEffect(() => {
        if (!map || !branch) {
            console.warn("⚠️ Missing map or branch");
            return;
        }

        // ✅ Validate coordinates
        const lng = branch.longitude;
        const lat = branch.latitude;

        if (!Number.isFinite(lng) || !Number.isFinite(lat)) {
            console.warn("⚠️ Invalid coordinates:", { lat, lng });
            return;
        }

        console.log("🔍 Opening popup at:", [lng, lat]);

        const formatCurrency = (value) => {
            return new Intl.NumberFormat('vi-VN', {
                style: 'currency',
                currency: 'VND'
            }).format(value);
        };

        const popupContent = `
            <div class="branch-popup">
                ${branch.image ? `<img src="${branch.image}" alt="${branch.branchName}" class="branch-popup-image" />` : ''}
                <div class="branch-popup-content">
                    <div class="branch-popup-header">
                        <h3 class="branch-popup-title">${branch.branchName || branch.name || "Unknown"}</h3>
                        <span class="branch-popup-badge badge-${(branch.performanceLevel || "AVERAGE").toLowerCase()}">
                            ${branch.performanceLevel || "AVERAGE"}
                        </span>
                    </div>
                    <div class="branch-popup-info">
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Loại:</span>
                            <span class="branch-popup-value">${branch.branchType || "RETAIL"}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Quản lý:</span>
                            <span class="branch-popup-value">${branch.manager || "N/A"}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Nhân viên:</span>
                            <span class="branch-popup-value">${branch.employeeCount || 0} người</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Tồn kho:</span>
                            <span class="branch-popup-value">${branch.currentStock || 0}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Nhu cầu:</span>
                            <span class="branch-popup-value">${branch.demand || 0}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Doanh thu:</span>
                            <span class="branch-popup-value">${formatCurrency(branch.monthlyRevenue || 0)}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Chi phí:</span>
                            <span class="branch-popup-value">${formatCurrency(branch.monthlyExpense || 0)}</span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Lợi nhuận:</span>
                            <span class="branch-popup-value" style="color: ${(branch.monthlyProfit || 0) >= 0 ? '#22C55E' : '#EF4444'}">
                                ${formatCurrency(branch.monthlyProfit || 0)}
                            </span>
                        </div>
                        <div class="branch-popup-row">
                            <span class="branch-popup-label">Địa chỉ:</span>
                            <span class="branch-popup-value">${branch.address || "N/A"}</span>
                        </div>
                    </div>
                    ${branch.optimization ? `
                        <div class="branch-popup-optimization">
                            <h4>📊 Tối ưu hoá vận hành</h4>
                            <div class="branch-popup-row">
                                <span class="branch-popup-label">Chiến lược:</span>
                                <span class="branch-popup-value">${branch.optimization.strategy || "N/A"}</span>
                            </div>
                            <div class="branch-popup-row">
                                <span class="branch-popup-label">Lợi nhuận dự đoán:</span>
                                <span class="branch-popup-value">${formatCurrency(branch.optimization.expectedProfit || 0)}</span>
                            </div>
                            <div class="branch-popup-row">
                                <span class="branch-popup-label">Nhu cầu dự báo:</span>
                                <span class="branch-popup-value">${branch.optimization.predictedDemand || 0}</span>
                            </div>
                            <div class="branch-popup-row">
                                <span class="branch-popup-label">Điểm hiệu quả:</span>
                                <span class="branch-popup-value">${branch.optimization.performanceScore || 0}/100</span>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        try {
            const popup = new maptilersdk.Popup({
                closeButton: true,
                closeOnClick: false,
                offset: [0, -15],
            })
                .setLngLat([lng, lat])  // ✅ Use longitude, latitude
                .setHTML(popupContent)
                .addTo(map);

            popup.on('close', () => {
                console.log("🔍 Popup closed");
                if (onClose) onClose();
            });

            popupRef.current = popup;

            return () => {
                if (popupRef.current) {
                    popupRef.current.remove();
                }
            };
        } catch (error) {
            console.error("❌ Error creating popup:", error);
        }

    }, [map, branch, onClose]);

    return null;
};

export default BranchPopUp;