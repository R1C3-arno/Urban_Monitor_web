import React, { useState, useEffect, useRef } from "react";
import { useNearestIncidents } from "../../Hooks/useNearestIncidents";
import "./NearestIncidentsLayer.css";

/**
 * NearestIncidentsLayer Component
 * Panel + map layer for KNN nearest incidents search
 */
const NearestIncidentsLayer = ({ map, visible = false }) => {
    const mapRef = useRef(map);
    const layersRef = useRef([]);
    const { nearestIncidents, loading, findNearest, clearNearest, query } = useNearestIncidents();

    const [targetLat, setTargetLat] = useState(10.7626);
    const [targetLng, setTargetLng] = useState(106.6602);
    const [k, setK] = useState(5);
    const [isSelectingLocation, setIsSelectingLocation] = useState(false);

    useEffect(() => {
        mapRef.current = map;
    }, [map]);

    // Draw results when data changes
    useEffect(() => {
        if (!mapRef.current || nearestIncidents.length === 0) return;

        if (!mapRef.current.isStyleLoaded()) {
            mapRef.current.once("style.load", drawResults);
            return;
        }

        drawResults();

        return () => cleanup();
    }, [nearestIncidents]);

    // Cleanup when hidden
    useEffect(() => {
        if (!visible) {
            cleanup();
            clearNearest();
        }
    }, [visible]);

    const handleSelectFromMap = () => {
        if (!mapRef.current) return;

        setIsSelectingLocation(true);
        mapRef.current.getCanvas().style.cursor = "crosshair";

        const onClick = (e) => {
            setTargetLat(e.lngLat.lat);
            setTargetLng(e.lngLat.lng);
            setIsSelectingLocation(false);
            mapRef.current.getCanvas().style.cursor = "";
            mapRef.current.off("click", onClick);
        };

        mapRef.current.once("click", onClick);
    };

    const handleSearch = async () => {
        await findNearest(targetLat, targetLng, k);
    };

    const drawResults = () => {
        if (!mapRef.current || nearestIncidents.length === 0) return;

        cleanup();

        const sourceId = "nearest-results-source";
        const lineLayerId = "nearest-lines";
        const pointLayerId = "nearest-points";
        const targetLayerId = "nearest-target";

        // Create features
        const features = [];

        // Lines from target to each incident
        nearestIncidents.forEach((item, index) => {
            features.push({
                type: "Feature",
                geometry: {
                    type: "LineString",
                    coordinates: [
                        [targetLng, targetLat],
                        [item.incident.lng, item.incident.lat],
                    ],
                },
                properties: { index },
            });

            // Incident point
            features.push({
                type: "Feature",
                geometry: {
                    type: "Point",
                    coordinates: [item.incident.lng, item.incident.lat],
                },
                properties: {
                    title: item.incident.title,
                    distance: item.distanceFormatted,
                    isIncident: true,
                },
            });
        });

        // Target point
        features.push({
            type: "Feature",
            geometry: {
                type: "Point",
                coordinates: [targetLng, targetLat],
            },
            properties: { isTarget: true },
        });

        mapRef.current.addSource(sourceId, {
            type: "geojson",
            data: { type: "FeatureCollection", features },
        });

        // Lines
        mapRef.current.addLayer({
            id: lineLayerId,
            type: "line",
            source: sourceId,
            filter: ["==", "$type", "LineString"],
            paint: {
                "line-color": "#3B82F6",
                "line-width": 2,
                "line-dasharray": [2, 2],
                "line-opacity": 0.7,
            },
        });

        // Incident points
        mapRef.current.addLayer({
            id: pointLayerId,
            type: "circle",
            source: sourceId,
            filter: ["all", ["==", "$type", "Point"], ["has", "isIncident"]],
            paint: {
                "circle-color": "#F59E0B",
                "circle-radius": 10,
                "circle-stroke-width": 2,
                "circle-stroke-color": "#ffffff",
            },
        });

        // Target point
        mapRef.current.addLayer({
            id: targetLayerId,
            type: "circle",
            source: sourceId,
            filter: ["all", ["==", "$type", "Point"], ["has", "isTarget"]],
            paint: {
                "circle-color": "#EF4444",
                "circle-radius": 12,
                "circle-stroke-width": 3,
                "circle-stroke-color": "#ffffff",
            },
        });

        layersRef.current.push(sourceId, lineLayerId, pointLayerId, targetLayerId);

        // Fit bounds
        const allCoords = [
            [targetLng, targetLat],
            ...nearestIncidents.map((i) => [i.incident.lng, i.incident.lat]),
        ];

        let minLng = Infinity, maxLng = -Infinity, minLat = Infinity, maxLat = -Infinity;
        allCoords.forEach(([lng, lat]) => {
            if (lng < minLng) minLng = lng;
            if (lng > maxLng) maxLng = lng;
            if (lat < minLat) minLat = lat;
            if (lat > maxLat) maxLat = lat;
        });

        mapRef.current.fitBounds(
            [[minLng, minLat], [maxLng, maxLat]],
            { padding: 100, maxZoom: 15 }
        );

        console.log(`✅ Drew ${nearestIncidents.length} nearest incidents`);
    };

    const cleanup = () => {
        if (!mapRef.current) return;

        layersRef.current.forEach((id) => {
            if (mapRef.current.getLayer(id)) {
                mapRef.current.removeLayer(id);
            }
            if (mapRef.current.getSource(id)) {
                mapRef.current.removeSource(id);
            }
        });

        layersRef.current = [];
    };

    if (!visible) return null;

    return (
        <div className="nearest-panel">
            <h3>🔍 Tìm sự cố gần nhất (KNN)</h3>

            <div className="input-group">
                <label>Vĩ độ (Lat):</label>
                <input
                    type="number"
                    value={targetLat}
                    onChange={(e) => setTargetLat(parseFloat(e.target.value))}
                    step="0.0001"
                />
            </div>

            <div className="input-group">
                <label>Kinh độ (Lng):</label>
                <input
                    type="number"
                    value={targetLng}
                    onChange={(e) => setTargetLng(parseFloat(e.target.value))}
                    step="0.0001"
                />
            </div>

            <div className="input-group">
                <label>Số lượng (K):</label>
                <input
                    type="number"
                    value={k}
                    onChange={(e) => setK(parseInt(e.target.value))}
                    min="1"
                    max="20"
                />
            </div>

            <button
                className="btn-select"
                onClick={handleSelectFromMap}
                disabled={isSelectingLocation}
            >
                {isSelectingLocation ? "🎯 Click vào bản đồ..." : "📍 Chọn từ bản đồ"}
            </button>

            <button className="btn-search" onClick={handleSearch} disabled={loading}>
                {loading ? "⏳ Đang tìm..." : "🔍 Tìm kiếm"}
            </button>

            {nearestIncidents.length > 0 && (
                <div className="results">
                    <h4>Kết quả ({nearestIncidents.length}):</h4>
                    <ul>
                        {nearestIncidents.map((item, index) => (
                            <li key={index}>
                                <span className="index">{index + 1}</span>
                                <div className="info">
                                    <span className="title">{item.incident.title}</span>
                                    <span className="distance">{item.distanceFormatted}</span>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default NearestIncidentsLayer;
