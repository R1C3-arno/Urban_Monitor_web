const OfficeIcon = () => {
    return (
        <div className="branch-icon">
            🏢
        </div>
    );
};

export default OfficeIcon;
