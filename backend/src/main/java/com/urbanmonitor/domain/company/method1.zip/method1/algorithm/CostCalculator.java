package com.urbanmonitor.domain.company.method1.algorithm;

import com.urbanmonitor.domain.company.method1.model.Method1OptimizationParams;

/**
 * Strategy Pattern - Calculate costs
 */
public interface CostCalculator {
    double calculate(double q, double p, int n, double k1,
                     double av, double theta, double ts,
                     Method1OptimizationParams params);
}