package com.urbanmonitor.domain.company.method1.model;

import lombok.*;
import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Method1OptimizationResult {
    private Integer n;
    private Double q;
    private Double p;
    private Double k1;
    private Double av;
    private Double theta;
    private Double ts;
    private Double tc;

    public Map<String, Object> toMap() {
        return new HashMap<String, Object>() {{
            put("n", n);
            put("lot_size", Math.round(q * 100.0) / 100.0);
            put("production_rate", Math.round(p * 100.0) / 100.0);
            put("safety_factor", Math.round(k1 * 10000.0) / 10000.0);
            put("setup_cost", Math.round(av * 100.0) / 100.0);
            put("defective_prob", Math.round(theta * 100000000.0) / 100000000.0);
            put("setup_time", Math.round(ts * 10000.0) / 10000.0);
            put("total_cost", Math.round(tc * 100.0) / 100.0);
        }};
    }
}