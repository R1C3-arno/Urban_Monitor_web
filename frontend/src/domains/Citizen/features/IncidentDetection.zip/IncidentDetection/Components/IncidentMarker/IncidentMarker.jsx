import React from "react";
import { INCIDENT_TYPES, MARKER_CONFIG, SEVERITY_COLORS } from "../../Config/incidentConfig";

/**
 * IncidentMarker Component
 * Custom marker for incident display
 */
export const IncidentMarker = ({ incident, onClick, isSelected = false }) => {
    const size = MARKER_CONFIG.SIZE_BY_SEVERITY[incident.level] || 12;
    const color = SEVERITY_COLORS[incident.level] || SEVERITY_COLORS.LOW;
    const icon = INCIDENT_TYPES[incident.type]?.icon || "⚠️";

    const style = {
        width: `${size * 2}px`,
        height: `${size * 2}px`,
        backgroundColor: color,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        border: isSelected ? "3px solid white" : "2px solid rgba(255,255,255,0.8)",
        boxShadow: isSelected ? "0 0 15px rgba(0,0,0,0.4)" : "0 2px 6px rgba(0,0,0,0.3)",
        transform: isSelected ? "scale(1.2)" : "scale(1)",
        transition: "all 0.2s ease",
        fontSize: `${size}px`,
    };

    return (
        <div style={style} onClick={() => onClick?.(incident)} title={incident.title}>
            {icon}
        </div>
    );
};

export default IncidentMarker;
