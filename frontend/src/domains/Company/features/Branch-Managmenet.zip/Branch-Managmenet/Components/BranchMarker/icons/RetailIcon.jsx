const RetailIcon = () => {
    return (
        <div className="branch-icon">
            🏪
        </div>
    );
};

export default RetailIcon;
