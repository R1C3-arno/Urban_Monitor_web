import { useEffect, useRef } from "react";
import * as turf from "@turf/turf";
import { CIRCLE_CONFIG } from "../../Config/incidentConfig";

/**
 * IncidentCircle Component
 * Draws danger zone circles on map (like TrafficCircle)
 */
const IncidentCircle = ({ map, data }) => {
    const mapRef = useRef(map);
    const layersRef = useRef([]);

    useEffect(() => {
        mapRef.current = map;
    }, [map]);

    useEffect(() => {
        if (!mapRef.current || !data || data.length === 0) return;

        // Wait for map style to load
        if (!mapRef.current.isStyleLoaded()) {
            mapRef.current.once("style.load", () => drawCircles());
            return;
        }

        drawCircles();

        return () => cleanup();
    }, [data]);

    const drawCircles = () => {
        if (!mapRef.current || !data) return;

        // Cleanup previous circles
        cleanup();

        data.forEach((circle, index) => {
            const sourceId = `incident-circle-source-${index}`;
            const layerId = `incident-circle-layer-${index}`;

            // Create circle polygon using turf
            const circlePolygon = turf.circle(circle.center, circle.radius / 1000, {
                steps: CIRCLE_CONFIG.SEGMENTS,
                units: "kilometers",
            });

            // Add source
            mapRef.current.addSource(sourceId, {
                type: "geojson",
                data: circlePolygon,
            });

            // Add fill layer
            mapRef.current.addLayer({
                id: layerId,
                type: "fill",
                source: sourceId,
                paint: {
                    "fill-color": circle.color,
                    "fill-opacity": circle.opacity || CIRCLE_CONFIG.OPACITY,
                },
            });

            // Add outline layer
            mapRef.current.addLayer({
                id: `${layerId}-outline`,
                type: "line",
                source: sourceId,
                paint: {
                    "line-color": circle.color,
                    "line-width": 2,
                    "line-opacity": 0.8,
                },
            });

            layersRef.current.push(sourceId, layerId, `${layerId}-outline`);
        });

        console.log(`✅ Drew ${data.length} incident circles`);
    };

    const cleanup = () => {
        if (!mapRef.current) return;

        layersRef.current.forEach((id) => {
            if (mapRef.current.getLayer(id)) {
                mapRef.current.removeLayer(id);
            }
            if (mapRef.current.getSource(id)) {
                mapRef.current.removeSource(id);
            }
        });

        layersRef.current = [];
    };

    return null;
};

export default IncidentCircle;
